import { BiChat, BiCodeAlt, BiSearchAlt2 } from "react-icons/bi";
import { TfiThought } from "react-icons/tfi";
import { HiDocumentSearch, HiDatabase } from "react-icons/hi";
import { TbReportAnalytics } from "react-icons/tb";

const size = 50;
const CodeLinkDev = ["https://dsi-ai-assistant-dev.azurewebsites.net/"];
const Services = [
    {
        id: 1,
        name: "AI Data Catalog",
        description: "AI data catalog tuned over DSI data and can answer all of your data catalog related queries.",
        link: ["/chat"],
        target: "_self",
        icon: <BiChat style={{ fontSize: size }} />,
        color: "#a659f4"
    },

    {
        id: 2,
        name: "Code Assistant",
        description: "The Codex assistant is proficient in programming languages including Python, SQL, SAS, BI DAX,R and can write, debug code",
        // link: ["http://localhost:5002"],
        // link: CodeLinkDev,
        // target: "_blank",
        link: ["codegen"],
        target: "_self",
        //target: "_self",
        icon: <BiCodeAlt style={{ fontSize: size }} />,
        color: "#2d5827"
    },
    {
        id: 3,
        name: "DMAT Assistant",
        description:
            "The DMAT Ops Assistant utilizes (SOP) documents to provide accurate responses to user queries, ensuring efficient operations and adherence to established protocols",
        // link: ["http://localhost:5002"],
        link: ["dmat"],
        // target: "_blank",
        target: "_self",
        icon: <HiDocumentSearch style={{ fontSize: size }} />,
        color: "#2d5897"
    },
    {
        id: 3,
        name: "EDA Assistant",
        description: "Self-Service page to ask queries and get insights from database",
        // link: ["http://localhost:5002"],
        link: ["eda"],
        // target: "_blank",
        target: "_self",
        icon: <HiDatabase style={{ fontSize: size }} />,
        color: "#ffc0cb"
    },
    {
        id: 4,
        name: "EDA Assistant (Field Activity)",
        description: "Self-Service page to ask queries and get insights from Field Activity Dashboard",
        // link: ["http://localhost:5002"],
        link: ["fad"],
        // target: "_blank",
        target: "_self",
        icon: <TbReportAnalytics style={{ fontSize: size }} />,
        color: "#dde3a2"
    },
    {
        id: 5,
        name: "Corporate Policy QnA Assistant",
        description:
            "The Corporate Policy QnA Assistant utilizes Policy documents to provide accurate responses to user queries, ensuring efficient operations and adherence to established protocols",
        // link: ["http://localhost:5002"],
        link: ["ps"],
        // target: "_blank",
        target: "_self",
        icon: <HiDocumentSearch style={{ fontSize: size }} />,
        color: "#2d5897"
    },
    {
        id: 6,
        name: "Multimedia Analyzer",
        description:
            "The Multimedia Analyzer extracts and analyzes information from various types of multimedia content, enabling applications such as object detection, speech recognition and more.",
        // link: ["http://localhost:5002"],
        link: ["mma"],
        // target: "_blank",
        target: "_self",
        icon: <HiDocumentSearch style={{ fontSize: size }} />,
        color: "#2d5827"
    }
];

export default Services;
