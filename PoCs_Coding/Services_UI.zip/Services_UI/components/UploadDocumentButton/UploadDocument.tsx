import { Text } from "@fluentui/react";
// import { ArrowUpload24Regular } from "@fluentui/react-icons";
// import { FaFileUpload } from "react-icons/fa";
// import { Video24Filled } from "@fluentui/react-icons";
import { VideoAdd24Filled } from "@fluentui/react-icons";
// import { VideoClip24Filled } from "@fluentui/react-icons";

import styles from "./UploadDocumentButton.module.css";

interface Props {
    className?: string;
    // onClick: () => void;
    disabled?: Boolean;
}

export const UploadDocumentButton = ({ className, disabled }: Props) => {
    return (
        <div className={`${styles.container} ${className ?? ""}`}>
            {/* <ArrowUpload24Regular /> */}
            {/* <Video24Filled /> */}
            <VideoAdd24Filled />
            {/* <VideoClip24Filled /> */}
            <Text>{"Video Upload"}</Text>
        </div>
    );
};
