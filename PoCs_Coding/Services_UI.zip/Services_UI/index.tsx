import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom/client";
import { HashRouter, Routes, Route, BrowserRouter } from "react-router-dom";
import { initializeIcons } from "@fluentui/react";
import "./index.css";
import { accessApi } from "./api";
import Layout from "./pages/layout/Layout";
import NoPage from "./pages/NoPage";
import OneShot from "./pages/oneshot/OneShot";
import Chat from "./pages/chat/Chat";
import CodeGen from "./pages/codegen/CodeGen";
import Home from "./pages/home/Home";
import Bidm from "./pages/bidm/Bidm";
import Ps from "./pages/ps/Ps";
import Mma from "./pages/mma/mma";
import Eda from "./pages/eda/Eda";
import Fad from "./pages/fad/Fad";
import { Access } from "./api";
initializeIcons();

export default function App() {
    //const [hasChatAccess, setHasChatAccess] = useState(false);
    const [hasAccess, setHasAccess] = useState<Access>({ hasChatAccess: false, hasDBAccess: true });

    const makeApiRequest = async () => {
        try {
            const response = await accessApi();
            console.log(response);
            setHasAccess(response);
        } catch (e) {
            console.log(e);
        }
    };

    useEffect(() => {
        // This function will be called only once during the initial render

        makeApiRequest();
        // Cleanup function (optional)
        return () => {
            console.log(hasAccess);
        };
    }, []);

    return (
        <HashRouter>
            <Routes>
                <Route path="/" element={<Layout />}>
                    <Route index element={<Home hasAccess={hasAccess} />} />

                    {hasAccess.hasChatAccess ? <Route path="chat" element={<Chat />} /> : <></>}
                    {/* <Route path="qa" element={<OneShot />} /> */}
                    <Route path="codegen" element={<CodeGen />} />
                    <Route path="dmat" element={<Bidm />} />
                    <Route path="ps" element={<Ps />} />
                    <Route path="mma" element={<Mma />} />
                    {hasAccess.hasDBAccess ? <Route path="eda" element={<Eda />} /> : <></>}
                    {hasAccess.hasDBAccess ? <Route path="fad" element={<Fad />} /> : <></>}

                    <Route path="*" element={<NoPage />} />
                </Route>
            </Routes>
        </HashRouter>
    );
}

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
    <React.StrictMode>
        <App />
    </React.StrictMode>
);
