import { Grid, Typography, Box, Card, CardContent } from "@mui/material";
import { useState, useEffect } from "react";
import ServicesCard from "../../components/Services/ServiceCard";
import Services from "../../components/Services/Services";
import { SectionDivider } from "../../components/SectionDivider/SectionDivider";
import NavSection from "../../components/NavSection/NavSection";

import styles from "./Home.module.css";
import { Access } from "../../api";

interface Props {
    hasAccess: Access;
}
function Home({ hasAccess }: Props) {
    return (
        <>
            <NavSection pageTitle="DSI OPENAI" />
            <div className={styles.body}>
                <Box>
                    <SectionDivider data="Services" />
                    <Grid container alignItems="stretch">
                        {/* {Services.map((data, key) => (
                            <>
                                {data.id == 1 && { hasChatAccess } && (
                                    <Grid item key={key} style={{ display: "flex" }} padding={2} xs={12} md={4}>
                                        <ServicesCard data={data} />
                                    </Grid>
                                )}

                            </>
                        ))} */}

                        {hasAccess.hasChatAccess ? (
                            <Grid item key={0} style={{ display: "flex" }} padding={2} xs={12} md={4}>
                                <ServicesCard data={Services[0]} />
                            </Grid>
                        ) : (
                            <></>
                        )}
                        <Grid item key={1} style={{ display: "flex" }} padding={2} xs={12} md={4}>
                            <ServicesCard data={Services[1]} />
                        </Grid>
                        <Grid item key={2} style={{ display: "flex" }} padding={2} xs={12} md={4}>
                            <ServicesCard data={Services[2]} />
                        </Grid>
                        <Grid item key={5} style={{ display: "flex" }} padding={2} xs={12} md={4}>
                            <ServicesCard data={Services[5]} />
                        </Grid>
                        <Grid item key={6} style={{ display: "flex" }} padding={2} xs={12} md={4}>
                            <ServicesCard data={Services[6]} />
                        </Grid>
                        {hasAccess.hasDBAccess ? (
                            <Grid item key={3} style={{ display: "flex" }} padding={2} xs={12} md={4}>
                                <ServicesCard data={Services[3]} />
                            </Grid>
                        ) : (
                            <></>
                        )}
                        {hasAccess.hasDBAccess ? (
                            <Grid item key={4} style={{ display: "flex" }} padding={2} xs={12} md={4}>
                                <ServicesCard data={Services[4]} />
                            </Grid>
                        ) : (
                            <></>
                        )}
                    </Grid>
                </Box>
            </div>
        </>
    );
}

export default Home;
