import os
import mimetypes
import time
import datetime
import logging
import openai
import requests , json
from flask import Flask, request, jsonify,render_template,redirect, url_for,session
from azure.search.documents import SearchClient
from approaches.retrievethenread import RetrieveThenReadApproach
from approaches.bidmAssistant import BidmAssistant
from approaches.chatreadretrieveread import ChatReadRetrieveReadApproach
from approaches.codegeneration import CodeGenerator
from approaches.balancedCatalog import BalancedCatalogApproach
from approaches.edaAssistant import EdaApproach
from approaches.edaRunDB import EdaRunDB
from approaches.fdaAssistant import FADapproach
from approaches.fadRunDB import FadRunDB
from azure.storage.blob import BlobServiceClient
from azure.core.credentials import AzureKeyCredential
import csv
import configparser
from fuzzywuzzy import fuzz
from fuzzywuzzy import process

# from flask_cors import CORS
# Replace these with your own values, either in environment variables or directly here
import pyodbc
from approaches.summarizer import UrlSummarizer
from approaches.fdatool import fdaTool

import msal

config = configparser.ConfigParser()
config.read('.config.ini')

AZURE_STORAGE_ACCOUNT = config['azure']['AZURE_STORAGE_ACCOUNT']
AZURE_STORAGE_CONTAINER = config['azure']['AZURE_STORAGE_CONTAINER']
AZURE_SEARCH_SERVICE = config['azure']['AZURE_SEARCH_SERVICE']
AZURE_SEARCH_INDEX = config['azure']['AZURE_SEARCH_INDEX']
AZURE_OPENAI_SERVICE = config['azure']['AZURE_OPENAI_SERVICE']
AZURE_OPENAI_GPT_DEPLOYMENT = config['azure']['AZURE_OPENAI_GPT_DEPLOYMENT']
AZURE_OPENAI_CHATGPT_DEPLOYMENT = config['azure']['AZURE_OPENAI_CHATGPT_DEPLOYMENT']
AZURE_OPENAI_CHATGPT_KEY = config['azure']['AZURE_OPENAI_CHATGPT_KEY']
AZURE_SEARCH_KEY = config['azure']['AZURE_SEARCH_KEY']
AZURE_BLOB_KEY = config['azure']['AZURE_BLOB_KEY']
AZURE_DB_INDEX= config['azure']['AZURE_DB_INDEX']
AZURE_BIDM_INDEX=config['azure']['AZURE_BIDM_INDEX']
AZURE_SEARCH_TABLE_INDEX = config['azure']['AZURE_SEARCH_TABLE_INDEX']
KB_FIELDS_CONTENT = "content"
KB_FIELDS_CATEGORY = os.environ.get("KB_FIELDS_CATEGORY") or "category"
KB_FIELDS_SOURCEPAGE = "sourcepage"

username = config['database_cred']['USERNAME']
password = config['database_cred']['PASSWORD']
server = config['database_cred']['SERVERNAME']
database = config['database']['CRM_DATABASE']
driver = config['database_cred']['DRIVER']
server_logging = config['logging_db']['SERVERNAME']
database_logging = config['logging_db']['LOGGING_DATABASE']

# Use the current user identity to authenticate with Azure OpenAI, Cognitive Search and Blob Storage (no secrets needed, 
# just use 'az login' locally, and managed identity when deployed on Azure). If you need to use keys, use separate AzureKeyCredential instances with the 
# keys for each service
# If you encounter a blocking error during a DefaultAzureCredntial resolution, you can exclude the problematic credential by using a parameter (ex. exclude_shared_token_cache_credential=True)
#azure_credential = DefaultAzureCredential()

# Used by the OpenAI SDK
openai.api_type = "azure"
openai.api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"
openai.api_version = "2023-03-15-preview"
openai.api_key = AZURE_OPENAI_CHATGPT_KEY

# Comment these two lines out if using keys, set your API key in the OPENAI_API_KEY environment variable instead
# openai.api_type = "azure_ad"
# openai_token = azure_credential.get_token("https://cognitiveservices.azure.com/.default")
# openai.api_key = openai_token.token

# Set up clients for Cognitive Search and Storage
search_client = SearchClient(
    endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
    index_name=AZURE_SEARCH_INDEX,
    credential=AzureKeyCredential(AZURE_SEARCH_KEY))

table_search_client = SearchClient(f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
    index_name=AZURE_SEARCH_TABLE_INDEX,
    credential=AzureKeyCredential(AZURE_SEARCH_KEY))

db_search_client = SearchClient(f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
    index_name=AZURE_DB_INDEX,
    credential=AzureKeyCredential(AZURE_SEARCH_KEY))

bidm_search_client = SearchClient(f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
    index_name=AZURE_BIDM_INDEX,
    credential=AzureKeyCredential(AZURE_SEARCH_KEY))

blob_client = BlobServiceClient(
    account_url=f"https://{AZURE_STORAGE_ACCOUNT}.blob.core.windows.net", 
    credential=AZURE_BLOB_KEY)
blob_container = blob_client.get_container_client(AZURE_STORAGE_CONTAINER)


client_id = config['AZURE_AUTH']['CLIENT_ID']
authority = 'https://login.microsoftonline.com/' + config['AZURE_AUTH']['TENENT']
scopes = ["User.Read"]  # Add additional scopes as needed
redirect_uri = 'http://localhost:5000'
#redirect_uri = 'https://dsi-assistant-dev.azurewebsites.net'
client_secret = config['AZURE_AUTH']['CLIENT_SECRET']




# Various approaches to integrate GPT and external knowledge, most applications will use a single one of these patterns
# or some derivative, here we include several for exploration purposes
ask_approaches = {
    "rtr": RetrieveThenReadApproach(search_client, AZURE_OPENAI_GPT_DEPLOYMENT, KB_FIELDS_SOURCEPAGE, KB_FIELDS_CONTENT),
    #"rrr": ReadRetrieveReadApproach(search_client, AZURE_OPENAI_GPT_DEPLOYMENT, KB_FIELDS_SOURCEPAGE, KB_FIELDS_CONTENT),
    #"rda": ReadDecomposeAsk(search_client, AZURE_OPENAI_GPT_DEPLOYMENT, KB_FIELDS_SOURCEPAGE, KB_FIELDS_CONTENT)
}

chat_approaches = {
    "rrr": ChatReadRetrieveReadApproach(search_client, table_search_client,db_search_client, AZURE_OPENAI_CHATGPT_DEPLOYMENT, AZURE_OPENAI_GPT_DEPLOYMENT, KB_FIELDS_SOURCEPAGE, KB_FIELDS_CONTENT),
    "bidm":BidmAssistant(bidm_search_client,AZURE_OPENAI_CHATGPT_DEPLOYMENT,AZURE_OPENAI_GPT_DEPLOYMENT,KB_FIELDS_SOURCEPAGE,KB_FIELDS_CONTENT),
    "bcr": BalancedCatalogApproach(search_client, table_search_client,db_search_client, AZURE_OPENAI_CHATGPT_DEPLOYMENT, AZURE_OPENAI_GPT_DEPLOYMENT, KB_FIELDS_SOURCEPAGE, KB_FIELDS_CONTENT),
    "eda":EdaApproach(AZURE_OPENAI_CHATGPT_DEPLOYMENT),
    "edadb":EdaRunDB(),
    "fad":FADapproach(AZURE_OPENAI_CHATGPT_DEPLOYMENT),
    "faddb": FadRunDB()
    
}

code_approaches = {
    "General":CodeGenerator(AZURE_OPENAI_CHATGPT_DEPLOYMENT,AZURE_OPENAI_GPT_DEPLOYMENT, "general"),
    "Python Code": CodeGenerator(AZURE_OPENAI_CHATGPT_DEPLOYMENT,AZURE_OPENAI_GPT_DEPLOYMENT, "python"),
    "SQL Code": CodeGenerator(AZURE_OPENAI_CHATGPT_DEPLOYMENT,AZURE_OPENAI_GPT_DEPLOYMENT, "SQL"),
    "SAS Code": CodeGenerator(AZURE_OPENAI_CHATGPT_DEPLOYMENT,AZURE_OPENAI_GPT_DEPLOYMENT, "SAS"),
    "PowerBI DAX Code": CodeGenerator(AZURE_OPENAI_CHATGPT_DEPLOYMENT,AZURE_OPENAI_GPT_DEPLOYMENT, "Power BI DAX"),
}

# logging.basicConfig(
#     level=logging.ERROR,  # Set the desired log level
#     format='%(asctime)s [%(levelname)s] %(message)s',  # Define the log message format
#   # Specify the log file name
#     filemode='a'  # Set the file mode to append
# )

# Create a logger instance
#logger = logging.getLogger()

app = Flask(__name__)

app.secret_key = "xyzflwivakaamkoqitpanjeknajgokab"
app.permanent_session_lifetime = datetime.timedelta(minutes=60)
#pca = msal.ConfidentialClientApplication(client_id=client_id, authority=authority,client_credential='qKS8Q~jGs_QtXCxeJqtlY2f-uQADmt6ay_IUga16')
pca = msal.ConfidentialClientApplication(client_id=client_id, authority=authority,client_credential=client_secret)

csv_list = []
def create_csv_list():
    for blob in blob_container.list_blobs():
        csv_list.append(blob.name)

create_csv_list() 



@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
# def catch_all(path):

#     if 'access_token' in request.cookies:
#         access_token = request.cookies['access_token']
#         # Implement token validation logic here
#         # You can use libraries like PyJWT to decode and verify the token

#         # If the token is valid, allow access to the requested path
#         return app.send_static_file(path or 'index.html')
#     else:
#         # If the user is not authenticated, redirect to the login page
#         return redirect(url_for('login'))
def catch_all(path):
    
    # Check if user is authenticated
    if is_auth():
        print(path)
        #access_token = request.cookies['access_token']
        # print('got from catch all')
        # Implement token validation logic here
        #if is_auth_token_valid(access_token):
            # If the token is valid, allow access to the requested path

        return app.send_static_file(path or 'index.html')
        

        
        
    elif 'code' in request.args:
        # If the request contains the 'code' parameter, it's a callback request
        print('--------------------------------')
        code = request.args.get('code')
        print(code)

        result = pca.acquire_token_by_authorization_code(
            code,
            scopes=scopes,
            redirect_uri=redirect_uri,
            
        )
        print(result)

        if 'error' in result:
            # Handle error case
            return 'Error: ' + result['error']

        #result = {'token_type': 'Bearer', 'scope': 'email openid profile User.Read User.ReadBasic.All', 'expires_in': 5346, 'ext_expires_in': 5346, 'access_token': 'eyJ0eXAiOiJKV1QiLCJub25jZSI6IlM2YTFDb1FzX2FvelVQM3R1MFowVERXbkJZR0JNa1BBNDRIZlBDbFJHTDQiLCJhbGciOiJSUzI1NiIsIng1dCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9iMDE3OTQ4Ny0zMDI2LTQ0ZjctYmNkNi0yNWVkNDUyMTM4ZDAvIiwiaWF0IjoxNjg3MjcwMjI5LCJuYmYiOjE2ODcyNzAyMjksImV4cCI6MTY4NzI3NTg3NiwiYWNjdCI6MCwiYWNyIjoiMSIsImFpbyI6IkFUUUF5LzhUQUFBQWxhMjdIdGpzQzNiU2RXWExOSkVQM0NDclp0TG1aQVJwT0k3M255MFpuQ3dob1E4My8xUjhpQjdXVlU0K0wxcDYiLCJhbXIiOlsid2lhIl0sImFwcF9kaXNwbGF5bmFtZSI6IkRTSS1Bc3Npc3RhbnQtRE1BVCIsImFwcGlkIjoiYTY0YWQ4N2YtYjUwOS00MzIxLTkzM2ItZjM4ZDRkYTk5MjJhIiwiYXBwaWRhY3IiOiIxIiwiZmFtaWx5X25hbWUiOiJPamhhIiwiZ2l2ZW5fbmFtZSI6Ik5pa2hpbCIsImlkdHlwIjoidXNlciIsImlwYWRkciI6Ijc0LjIzNS4xMy4yMDIiLCJuYW1lIjoiT2poYSwgTmlraGlsIiwib2lkIjoiNmVjZTZkODMtYzVhMS00MWU0LTg4NGEtMTUxZTNlY2VmYTY5Iiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTkyNjc3Njg3LTU4MTc2NzgzNy02MjY2NzE4NjktMTYxOTc1IiwicGxhdGYiOiIzIiwicHVpZCI6IjEwMDMyMDAyOUNFNjlFMTIiLCJyaCI6IjAuQVhVQWg1UVhzQ1l3OTBTODFpWHRSU0U0MEFNQUFBQUFBQUFBd0FBQUFBQUFBQUIxQUprLiIsInNjcCI6ImVtYWlsIG9wZW5pZCBwcm9maWxlIFVzZXIuUmVhZCBVc2VyLlJlYWRCYXNpYy5BbGwiLCJzdWIiOiJsd2tBNHpDMUVjTmllZ0d0VlRhWXQ2bHYzWVNVRU10MU93MkZCdWpXVjFRIiwidGVuYW50X3JlZ2lvbl9zY29wZSI6Ik5BIiwidGlkIjoiYjAxNzk0ODctMzAyNi00NGY3LWJjZDYtMjVlZDQ1MjEzOGQwIiwidW5pcXVlX25hbWUiOiJub2poYUBkc2kuY29tIiwidXBuIjoibm9qaGFAZHNpLmNvbSIsInV0aSI6IkhiQ3FDN1EyaWstTmNLdGVudGxRQUEiLCJ2ZXIiOiIxLjAiLCJ3aWRzIjpbImI3OWZiZjRkLTNlZjktNDY4OS04MTQzLTc2YjE5NGU4NTUwOSJdLCJ4bXNfc3QiOnsic3ViIjoib25jMkZ1VG5maWRTVlJNRzdob2ZEblotUWNDMEdtcHRSMllSZTJHbWdQdyJ9LCJ4bXNfdGNkdCI6MTM4ODc5MzUwM30.FpcjoVBQDPYHlzt_uQXp8U-QoTRG-lL3DyvlloUHJjAx1o0YEqSHBhiyVpYFRfPS_ndVHgQaS1c6fDdUU6FjsRCeVSk8RIZ2i1qM8yt391o1okViVeaw1X3EQj-cLdReKWSK4w45SnM1DpOs9xfAJEipCVF84KYVTRhNI3ck8Wt0OYRbrxd46m35si3cFFQMspFy8wNEmbQy2A2R4Vn42eA1kPOFJBhUYkTTNgCLMDDDuTYU7CK1D4TNvhWc7fNp21mAlgSI1a0rVnwFMe7z-RhtWIbgU1RlRvVlC6qFsXPBt9Z9bq4vhTDdVVOQAVSDOEonSAfxIyE1Xv8Jmj38jg', 'refresh_token': '0.AXUAh5QXsCYw90S81iXtRSE40H_YSqYJtSFDkzvzjU2pkip1AJk.AgABAAEAAAD--DLA3VO7QrddgJg7WevrAgDs_wUA9P-fMkYsGCY2RRU4TkL07-oTJsraAWkH1YSS18UTuBkhsjVkJMtn4h13krtL14UOmEC7v6zIHRgIZR7PT3qMCRZ27wzLa5vOrXyntBo-UfgC62g-wvb0EQmkeFHUY8-EuuyyYhTWsAwuVpDrwi9IIYOdF0GTBLcJBxJ8ONLzxor0MiQB0r-g9uReisVa659-7UBwMM0aAzH3eV0Q_r3Z85kYLrSObK23JYv6GPrLf-RlzwCa6fL3WZjtnXPmcneTeTd2sdF3GFtBJG4aMNPVIUsL5ZoSETMXaNXgQYJFp7WpBT2Pu9Q0E4QN-0Zyb5Kj8M60sY9dwXlbRDGX2ySQadNmhXz5FnWvEJ4T40dZ6Mj3BbK5qYsWk6hHX7UUUwrcGp1hiGQp_sw20WIfJVaXhMZ2n59NI7UqvPVpgnRlN-VGaooWS09M59wqIAmhgqvk7kUEN368dD2f9iXESLzF9Io2SDuVvGecIjI7NdxNLPr8d-a1Wimi5QI7yFz74igesfDFCylCYVZ_c4aPk9RerggsZPpFxpy2ff4tVNzk2dIOHQfq6wSfoZeW0qq-d_KDD952aIiVT7zPKnePzE3oCyOD-u3Nhn6l90UmPdNnZvr4_vnOad56ooRtIeUdqSuB3OZGnobw7wDJrdx_bHRIyvqKgSgXeIwzkSIbDGnUwBJlsR0cvFEubp--qntpV_C8bkLSlFE0bcqZ0jJvBxaqZemE5vHcodm0Ry_uE1bjbA8VwYka0Sg1BRUXiJcYuMpHot3XWQcIHd9ejPxYuK8IUcxfjvhoy0BwzhNCoL7z', 'id_token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiJhNjRhZDg3Zi1iNTA5LTQzMjEtOTMzYi1mMzhkNGRhOTkyMmEiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vYjAxNzk0ODctMzAyNi00NGY3LWJjZDYtMjVlZDQ1MjEzOGQwL3YyLjAiLCJpYXQiOjE2ODcyNzAyMjksIm5iZiI6MTY4NzI3MDIyOSwiZXhwIjoxNjg3Mjc0MTI5LCJhaW8iOiJBVFFBeS84VEFBQUF3M3JibEZTVHVDejNReVZzQ25XZG92b0VMYnhYWVltc3ArMEZpSjZuRkErbnRUeU9RK015S3dzOGl4YjFKNkpxIiwibmFtZSI6Ik9qaGEsIE5pa2hpbCIsIm9pZCI6IjZlY2U2ZDgzLWM1YTEtNDFlNC04ODRhLTE1MWUzZWNlZmE2OSIsInByZWZlcnJlZF91c2VybmFtZSI6Im5vamhhQGRzaS5jb20iLCJyaCI6IjAuQVhVQWg1UVhzQ1l3OTBTODFpWHRSU0U0MEhfWVNxWUp0U0ZEa3p2empVMnBraXAxQUprLiIsInN1YiI6Im9uYzJGdVRuZmlkU1ZSTUc3aG9mRG5aLVFjQzBHbXB0UjJZUmUyR21nUHciLCJ0aWQiOiJiMDE3OTQ4Ny0zMDI2LTQ0ZjctYmNkNi0yNWVkNDUyMTM4ZDAiLCJ1dGkiOiJIYkNxQzdRMmlrLU5jS3RlbnRsUUFBIiwidmVyIjoiMi4wIn0.bQf56i8NC-H4AMJwtn7onVOpzHkD7Tzw_z4sqTCAKps_F-kWoats378vIZZThKFSysbMHqebNuymETVlPNm3PyOe-Cy-4xxHU21oKD2kUTCAgf4AkwDbpemniLx9-qOwdZUjRBS1bbn0OnFREhDGADv7qZX2XB8-kq6u6oePBKQHMaf1NqqjKqZmrnYLsdUyod-PwCAEkXodEgev4ncz7wa1XLjRQqJ4Aa9G1MQsKBdwY5-l9GjBkf7tSud5KayAMQlFsEkW3d4u23AaU6tVkuERERfsg5AVno5Lms7gR2auLRepIE-COnaz4S5PvMLup67-oJglMi_tyheXhZEIQA', 'client_info': 'eyJ1aWQiOiI2ZWNlNmQ4My1jNWExLTQxZTQtODg0YS0xNTFlM2VjZWZhNjkiLCJ1dGlkIjoiYjAxNzk0ODctMzAyNi00NGY3LWJjZDYtMjVlZDQ1MjEzOGQwIn0', 'id_token_claims': {'aud': 'a64ad87f-b509-4321-933b-f38d4da9922a', 'iss': 'https://login.microsoftonline.com/b0179487-3026-44f7-bcd6-25ed452138d0/v2.0', 'iat': 1687270229, 'nbf': 1687270229, 'exp': 1687274129, 'aio': 'ATQAy/8TAAAAw3rblFSTuCz3QyVsCnWdovoELbxXYYmsp+0FiJ6nFA+ntTyOQ+MyKws8ixb1J6Jq', 'name': 'Ojha, Nikhil', 'oid': '6ece6d83-c5a1-41e4-884a-151e3ecefa69', 'preferred_username': 'nojha@dsi.com', 'rh': '0.AXUAh5QXsCYw90S81iXtRSE40H_YSqYJtSFDkzvzjU2pkip1AJk.', 'sub': 'onc2FuTnfidSVRMG7hofDnZ-QcC0GmptR2YRe2GmgPw', 'tid': 'b0179487-3026-44f7-bcd6-25ed452138d0', 'uti': 'HbCqC7Q2ik-NcKtentlQAA', 'ver': '2.0'}}
        

        user_name = result['id_token_claims']['preferred_username']
        session['access_token'] = result['access_token']
        session['user_name'] = result['id_token_claims']['preferred_username']
        # Set the access token as a cookie
        response = redirect(url_for('catch_all'))
        response.set_cookie('username', user_name)
        
        return response
    else:
        # If the user is not authenticated and it's not a callback request, redirect to the login page
        #print('BLLLLLLLLLLLL --------------------------------')
        return redirect(url_for('login'))



@app.route('/login')
def login():
    #print('got from login all')
    if 'access_token' in session:
        #access_token = request.cookies['access_token']
        # If the user is already authenticated, redirect to the root path
        return redirect(url_for('catch_all'))


    
    auth_url = pca.get_authorization_request_url(
        scopes=scopes,
        redirect_uri=redirect_uri,
        prompt='select_account',  # Forces the user to select their account on each login attempt
        state='random_state'  # Add a random state value to mitigate CSRF attacks
    )
    return redirect(auth_url)

    
# Serve content files from blob storage from within the app to keep the example self-contained. 
# *** NOTE *** this assumes that the content files are public, or at least that all users of the app
# can access all the files. This is also slow and memory hungry.
@app.route("/content/<path>")
def content_file(path):
    if is_auth():
        closest_match,score = process.extractOne(path, csv_list)
        data = " "
        min_score = 70
        if score > min_score:
            blob = blob_container.get_blob_client(closest_match).download_blob()
            blob_data = blob.readall().decode('latin-1')
            csv_data = csv.reader(blob_data.splitlines())
            data = list(csv_data)
            return render_template('display_csv.html', file_name = closest_match ,data=data)
        # mime_type = blob.properties["content_settings"]["content_type"]
        # if mime_type == "application/octet-stream":
        #     mime_type = mimetypes.guess_type(path)[0] or "application/octet-stream"
        # return blob.readall(), 200, {"Content-Type": mime_type, "Content-Disposition": f"inline; filename={path}"}
        return render_template('display_csv.html', file_name = path,data=data)
    else:
        return redirect(url_for('login'))

# @app.route("/db/accessdb")
# def access_db():
#     if is_auth() and session['user_name'] in db_auth_list():
#         file_name = "access_db.csv"
#         with open(file_name, 'r') as file:
#             csv_data = csv.reader(file)
#             data = list(csv_data)
#         return render_template('display_csv.html', file_name = file_name ,data=data)
#     else:
#         return redirect(url_for('login'))

@app.route("/ask", methods=["POST"])
def ask():
    #ensure_openai_token()
    approach = request.json["approach"]
    #print(approach)
    try:
        impl = ask_approaches.get(approach)
        if not impl:
            return jsonify({"error": "unknown approach"}), 400
        r = impl.run(request.json["question"], request.json.get("overrides") or {})
        return jsonify(r)
    except Exception as e:
        logging.exception("Exception in /ask")
        return jsonify({"error": str(e)}), 500
    
@app.route("/chat", methods=["POST"])
def chat():
    #ensure_openai_token()
    if is_auth() :
    #and isCatalogAuth():
        #log_request(question=request.json["history"][-1]["user"],api='ai-catalog')
        #log_request(question=request.json["history"][-1]["user"],api='ai-catalog')
        request_timestamp = datetime.datetime.now()
        approach = request.json["approach"]
        try:
            impl = chat_approaches.get(approach)
            if not impl:
                return jsonify({"error": "unknown approach"}), 400
            #r = impl.run(request.json["history"], request.json.get("overrides") or {})
            tokens,r = impl.run(request.json["history"], request.json.get("overrides") or {})
            log_request(input_timestamp=request_timestamp, question=request.json["history"][-1]["user"],api='ai-catalog', response=r,approach=approach, token=tokens)
            return jsonify(r)
        except Exception as e:
            logging.exception("Exception in /chat")
            return jsonify({"error": str(e)}), 500
    else:
        return jsonify({"error": "Unauthorized or your access token has expired. Please login again if you have access to this resource."}), 401
    
@app.route("/code", methods=["POST"])
def code():
    #ensure_openai_token()
    if is_auth():
        log_request(question=request.json["history"][-1]["user"],api='ai-assistant')
        approach = request.json["approach"]
        try:
            impl = code_approaches.get(approach)
            if not impl:
                return jsonify({"error": "unknown approach"}), 400
            r = impl.run(request.json["history"], request.json.get("overrides") or {})
            return jsonify(r)
        except Exception as e:
            logging.exception("Exception in /chat")
            return jsonify({"error": str(e)}), 500
    else:
        return jsonify({"error": "Unauthorized or Your access token has expired. Please login again if you have access to this resource."}), 401

@app.route("/bidm", methods=["POST"])
def bidm():
    #ensure_openai_token()
    if is_auth():
        #log_request(question=request.json["history"][-1]["user"],api='ai-bidm')
        request_timestamp = datetime.datetime.now()
        approach = request.json["approach"]
        try:
            impl = chat_approaches.get(approach)
            if not impl:
                return jsonify({"error": "unknown approach"}), 400
            tokens,r = impl.run(request.json["history"], request.json.get("overrides") or {})
            log_request(input_timestamp=request_timestamp,question=request.json["history"][-1]["user"],api='ai-bidm',response=r,approach=approach,token=tokens)
            return jsonify(r)
        except Exception as e:
            logging.exception("Exception in /bidm")
            return jsonify({"error": str(e)}), 500
    else:
        return jsonify({"error": "Unauthorized or Your access token has expired. Please login again if you have access to this resource."}), 401


@app.route('/eda',methods=['POST'])
def eda():
    print(request.json)
    if is_auth() and isDBAuth():
        #log_request(question=request.json["history"][-1]["user"],api='ai-eda')
        request_timestamp = datetime.datetime.now()
        approach = request.json["approach"]

        try:
            impl = chat_approaches.get(approach)
            if not impl:
                return jsonify({"error": "unknown approach"}), 400
            tokens,r = impl.run(request.json["history"], request.json.get("overrides") or {})
            #log_request(input_timestamp=request_timestamp, question=request.json["history"][-1]["user"],api='ai-eda', response=r,approach=approach, token=tokens)
            return jsonify(r)
        except Exception as e:
            logging.exception("Exception in /eda")
            return jsonify({"error": str(e)}), 500
    else:
        return jsonify({"error": "Unauthorized or Your access token has expired. Please login again if you have access to this resource."}), 401
@app.route('/fad',methods=['POST'])
def fad():
    print("Succesfull")
    print(request.json)
    if is_auth() and isDBAuth():
        #log_request(question=request.json["history"][-1]["user"],api='ai-eda')
        request_timestamp = datetime.datetime.now()
        approach = request.json["approach"]

        try:
            impl = chat_approaches.get(approach)
            if not impl:
                return jsonify({"error": "unknown approach"}), 400
            tokens,r = impl.run(request.json["history"], request.json.get("overrides") or {})
            #log_request(input_timestamp=request_timestamp, question=request.json["history"][-1]["user"],api='ai-eda', response=r,approach=approach, token=tokens)
            return jsonify(r)
        except Exception as e:
            logging.exception("Exception in /fad")
            return jsonify({"error": str(e)}), 500
    else:
        return jsonify({"error": "Unauthorized or Your access token has expired. Please login again if you have access to this resource."}), 401

# -----------------FDA scraping code start -----------------------------#    
@app.route('/fda/<keywords>/<selection>',methods=['GET'])
def handle_fda_Tool(keywords,selection):
    print(keywords,selection + " recieved at backend")
    return fdaTool(keywords,selection) 

# -----------------FDA scraping code end -----------------------------#

# ------------------ Url Summarizer ------------------------------#

@app.route('/urlSum',methods=['POST'])
def handle_url_summarization():
    return UrlSummarizer()

# ------------------ Url Summarizer end ---------------------------#

@app.route('/api/auth',methods=['GET'])
def catalogAuth():
    # print("hello")
    if is_auth():
        auth_catalog = isCatalogAuth()
        auth_db = isDBAuth()
        # print(auth_db)
        return jsonify({"hasChatAccess":auth_catalog,"hasDBAccess":auth_db}),200
    else:
        return jsonify({"hasChatAccess":False,"hasDBAccess":False}),200
# def ensure_openai_token():
#     global openai_token
#     if openai_token.expires_on < int(time.time()) - 60:
#         openai_token = azure_credential.get_token("https://cognitiveservices.azure.com/.default")
#         openai.api_key = openai_token.token

def is_auth_token_valid(token) -> bool:
    headers = {  
        'Authorization': 'Bearer ' + token,  
        'Content-Type': 'application/json'  
    }  
    
    response = requests.get('https://graph.microsoft.com/v1.0/me', headers=headers)  
    print(response.status_code)
    if response.status_code == 200:  
        user_details = json.loads(response.content)
        print(user_details)  
        return True
    else:  
        print('Failed to get user details. Status code:', response.status_code)
        return False  
    
def is_auth() -> bool:
    if 'access_token' in session:
        return True
    else:
        return False
    
def log_request(input_timestamp,question,api,response,approach,token=3912):
    chatgpt = ['bcr']
    logging_conn_string = 'DRIVER='+driver+';SERVER=tcp:'+server_logging+';DATABASE='+database_logging+';UID='+username+';PWD='+ password + ';Authentication=ActiveDirectoryPassword'
    try:
        print('Connecting to logging database')
        conn = pyodbc.connect(logging_conn_string)
        db_conn = True
        print('success')
        if approach in chatgpt:
            model_name = 'gpt-3.5-turbo'
        else:
            model_name = 'gpt-4'
        if db_conn:
            current_timestamp = datetime.datetime.now()
            user = session['user_name']
            #user = 'user.name'
            response = str(response['answer'])
            resp_time = current_timestamp - input_timestamp
            query = f"""Insert into LOGGING.log_table 
            (APPLN, LOG_DT_TM, USR_NM,QUERY,RESPONSE,NO_TOKENS,RESP_DT_TM,model_name,RESP_TM_SEC) 
            VALUES 
            ('{api}', '{input_timestamp}', '{user}','{question}',QUOTENAME('{response}', ''''),{token},
            '{current_timestamp}','{model_name}','{resp_time.seconds}' );"""
            print(query)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO LOGGING.log_table (APPLN, LOG_DT_TM, USR_NM, QUERY, RESPONSE, NO_TOKENS, RESP_DT_TM, model_name, RESP_TM_SEC) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",(api, input_timestamp, user, question, response, token, current_timestamp, model_name, resp_time.seconds))
            conn.commit()
            cursor.close()
            conn.close()

    except Exception as e:
        print('Exception Occured', e)
        db_conn = False

    

def auth_list()->list:
    return ['nojha@dsi.com','vv@dsi.com']

def db_auth_list()->list:
    return ['nojha@dsi.com','gbhatia2@dsi.com','dchauhan@dsi.com','srathore@dsi.com','mparag@dsi.com','snair2@dsi.com']

# def isCatalogAuth()->bool:
#     return True
def isDBAuth():
    if session['user_name'] in db_auth_list():
        return True
    return True
def isCatalogAuth()->bool:
    #  headers = {  
    #      'Authorization': 'Bearer ' + session['access_token'],  
    #      'Content-Type': 'application/json'  
    #  }
    #  response = requests.get("https://graph.microsoft.com/v1.0/me/memberOf?$filter=id eq '9a4eaa8f-199e-44c0-94c7-8dc563720028'", headers=headers)  
    #  if response.status_code == 200: 
         #print('success')
    if session['user_name'] in db_auth_list(): 
        return True
    else:
        return False
    

if __name__ == "__main__":
    app.run(debug=True)
