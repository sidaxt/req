import { useRef, useState, useEffect } from "react";
import styles from "./urlSum.module.css";
import bidmIcon from "../../assets/bidmIcon.svg";
import { UrlSumResponse } from "../../api";
import NavSection from "../../components/NavSection/NavSection";
import {Button, TextField, Alert, Snackbar, Tooltip, Typography} from "@mui/material";
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';

const UrlSum = () => {

    // const [isLoading, setIsLoading] = useState<boolean>(false);
    const [summary, setSummary] = useState<string>('');
    // const [readMoreLink, setReadMoreLink] = useState<string>('');
    const [urlkey, setUrlKey] = useState<string>('');
    const [selection, setSelection] = useState<string>('normal')
    // const [emailAlert, setEmailAlert] = useState<boolean>(false);
    // const handleAlertClose = () => {
    //     setEmailAlert(false);
    // };
    const isDisabled = urlkey.trim() === '';
    const makeApiRequest = async () => {
        // console.log(urlkey)
        console.log(selection)
        const response = await UrlSumResponse(urlkey,selection);
        setSummary(response.summary);
        // console.log(response.summary);
    }
    return (
        <>
        <div >
            <NavSection pageTitle="URL Text Summarizer" />
            <div className={styles.chatWindow}>
                <div className={styles.chatInput}>
                    <TextField id="outlined-basic" label="Enter URL of Interest, you want to get Summarized" type="text" value={urlkey} fullWidth={true} variant={'outlined'} onChange={(e) => setUrlKey(e.target.value)}/>
                </div>
                <Tooltip title="Please enter a URL you would like to Summarize" placement="bottom" disableHoverListener={!isDisabled}>
                <div className={styles.buttonContainer}>  
                        <Button sx={{marginRight : 1}} variant={"contained"} onClick={makeApiRequest} disabled={isDisabled}>Summarize</Button>
                </div>
                </Tooltip>
                    <FormControl>
                            <RadioGroup row className={styles.buttonContainer} sx={{paddingTop : 1}}
                                value={selection} onChange={(e) => {setSelection(e.target.value); setSummary('');}} >
                                    <FormControlLabel value="normal" control={<Radio />} label="Normal Approach"  sx={{ paddingRight : 4}}/>
                                    <FormControlLabel value="statistical" control={<Radio />} label="Statistical Approach" />
                            </RadioGroup>
                    </FormControl>
                {summary && (
                    <div>
                    <h2>Summary</h2>
                    <Typography variant="body1" gutterBottom sx={{whiteSpace: "pre-line"}}>
                        <p>{summary}</p>
                    </Typography> 
                    </div>
                )}
                {/* <Snackbar open={emailAlert} autoHideDuration={6000} onClose={handleAlertClose}>
                    <Alert onClose={handleAlertClose} severity="success" sx={{ width: "100%" }}>
                        You have Successfully Subscribed to FDA Email Notifications !
                    </Alert>
                </Snackbar>     */}
            </div>
        </div>    
        </>
    );
};

export default UrlSum;
