import openai
import urllib
from flask import request, jsonify



def UrlSummarizer() :
            request_data = request.json
            url = urllib.parse.unquote(request_data.get('url', ''))
            selection = request_data.get('selection', '')
            # print("Received URL:", url)  # Debug statement
            def api_call(input_str):
                response = openai.ChatCompletion.create(
                    engine="gptdemo", # The deployment name you chose when you deployed the GPT-35-Turbo or GPT-4 model.
                    messages=[
                        {"role": "system", "content": "You are a helpful Assistant trained in large language models who analyses text and data and provide summaries"},
                        {"role": "user", "content": input_str}
                    ],
                    temperature = temper
                )
                return (response['choices'][0]['message']['content']) 
            if selection == 'normal':
                temper = 0.4
                prompt = "please summarize the following in detail with atleast 2 paragraphs, Use 3 to 5 sentence paragraphs : \n\n" + url

            if selection == 'statistical':
                temper = 0.1
                prompt = """please give a analytical/statistical overview of the following, give a row wise summary from the data present in the page. Include details about most important points :
                            example : Question : please give a summary of the school data

                                      Answer:               | Name    | Age | Occupation   |
                                                            |---------|-----|--------------|
                                                            | Alice   | 30  | Engineer     |
                                                            | Bob     | 25  | Scientist    |
                                                            | Charlie | 35  | Artist       |
                                \n\n""" + url
            summary = api_call(prompt)
            return jsonify({"summary": summary})