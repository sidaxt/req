import yt_dlp
import whisper
from hugchat import hugchat
import os
import streamlit as st
import openai

# set your openai key here
key = "5d69dd6f0aa14121ae81066435443abf"
AZURE_OPENAI_SERVICE = "OpenAI-PoC-East"
openai_api_version = "2023-03-15-preview" 
openai_api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com" 
openai_api_key = key
openai.api_type = "azure"
openai.api_version = openai_api_version 
openai.api_base = openai_api_base # Your Azure OpenAI resource's endpoint value.
openai.api_key = openai_api_key
os.environ["OPENAI_API_KEY"] = openai_api_key

# Load whisper model
whisper_model = whisper.load_model("tiny")

## API Function
def api_call(input_str, temp, prompt):
    temp = temp
    prompt = prompt
    response = openai.ChatCompletion.create(
        engine="gptdemo",
        messages=[
            {"role": "system", "content": prompt},
            {"role": "user", "content": input_str}
        ], 
        temperature = temp
    )
    return (response)

#Function for saving audio from input video id of youtube
def download(video_id: str) -> str:
    # video_url = f'https://www.youtube.com/watch?v={video_id}'
    video_url = video_id
    ydl_opts = {
        'ffmpeg_location':os.path.realpath('C:\\ffmpeg\\ffmpeg-2024-03-04-git-e30369bc1c-full_build\\bin\\ffmpeg.exe'),
        'format': 'm4a/bestaudio/best',
        'paths': {'home': 'audio/'},
        'outtmpl': {'default': '%(id)s.%(ext)s'},
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'm4a',
        }]
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        error_code = ydl.download([video_url])
        if error_code != 0:
            raise Exception('Failed to download video')

    return f'audio/{video_id}.m4a'


# Function to convert video to audio
# def convert_to_audio(youtube_url):
#     with youtube_dl.YoutubeDL({}) as ydl:
#         info_dict = ydl.extract_info(youtube_url, download=False)
#         video_url = info_dict.get("url", None)
#         if video_url:
#             video_clip = mp.VideoFileClip(video_url)
#             audio_clip = video_clip.audio
#             audio_clip.write_audiofile("audio_file.wav")
#             return "audio_file.wav"
#         else:
#             return None

# Function to generate answer from question using model
# def generate_answer(question):
#     question_answering = pipeline("question-answering")
#     context = "This is the context where we expect to find the answer to the question."
#     return question_answering(question=question, context=context)

# Main Streamlit app
def main():
    video_content = ""
    st.title("VIDEO ANALYZER")

    # Input for YouTube link
    youtube_link = st.text_input("Enter Video Link:")

    # Progress bar for conversion
    progress_bar = st.progress(0)

    if st.button("Convert to Audio"):
        if youtube_link:
            st.write("Converting video to audio...")
            download(youtube_link)
            # files = os.listdir('audio')
            # for file_path in files:
            #     transcription = whisper_model.transcribe(os.path.join('audio',file_path), fp16=False) 
            #     print(type(transcription))
            #     # print(transcription['text'])
            #     video_content = transcription['text']
            #     print(video_content)
            #     st.success("Audio conversion completed!")
            #     break
            st.success("Audio conversion completed!")
            # if audio_file:
            #     st.success("Audio conversion completed!")
            # else:
            #     st.error("Failed to convert video to audio!")
        else:
            st.warning("Please enter a valid YouTube link!")

    # Input for question
    question = st.text_area("Enter your question:")

    # Output window for answer
    if st.button("Get Answer"):
        if question:
            files = os.listdir('audio')
            for file_path in files:
                transcription = whisper_model.transcribe(os.path.join('audio',file_path), fp16=False) 
            system_prompt = """You will provide information for the user input based on the below content {0}""".format(transcription['text'])
            print(system_prompt)
            user_prompt = question
            temp = 0.5
            st.write("Generating answer...")
            answer = api_call(user_prompt, temp, system_prompt)
            st.success("Answer generated successfully!")
            st.write("Answer:", answer['choices'][0]['message']['content'])
        else:
            st.warning("Please enter a question!")

if __name__ == "__main__":
    main()
